```
Student name: Linda Danvers
Student number: 123456
Course code: ITI1121
Lab: Lab02
Course section: 02
Java: 1.8
```
